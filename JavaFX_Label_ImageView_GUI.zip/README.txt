JavaFX Label + ImageView GUI (no Java source code)

Files:
- MainView.fxml: JavaFX GUI layout using FXML; includes a Label and an ImageView.
- landscape.png: sample image shown in the ImageView.

Open MainView.fxml in Scene Builder to view/edit the GUI visually.
Keep landscape.png in the same folder as MainView.fxml.

Note: FXML defines the layout, but launching it as an application still requires a JavaFX runtime and a small application loader or an existing JavaFX project.
